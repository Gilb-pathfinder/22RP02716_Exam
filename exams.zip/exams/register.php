
<?php
require_once 'db.php';
include 'auth.php';
$errors = [];

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $username = htmlspecialchars($_POST['username']);
    $password = htmlspecialchars($_POST['password']);

    if(empty($username) || !preg_match("/^[a-zA-Z ]*$/",$username)){
     $errors[] = "Invalid UserName";
    }
   else if(empty($password) || !preg_match("/^[a-zA-Z]*$/",$password) || !strlen($password) > 6){
        $errors[] = "Invalid password,must meet 8 characters";
       }
       else{
  $sql = "SELECT * FROM users WHERE username = '$username'";
  $query = mysqli_query($connect,$sql);
  
  if($query === TRUE){
    $errors[] = " UserName Already Exist";
  }else{
    $hashed = password_hash($password,PASSWORD_DEFAULT);
    $insert = "INSERT INTO users (username,password) VALUES ('$username','$hashed')";
    $exec = mysqli_query($connect,$insert);

   header("Location: index.php");
  }

       }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create your account</title>
</head>
<body>
  

<div class="container">
<h1>Create account</h1>
 <form action="" method="POST">

 <?php 
 foreach($errors as $error){
    echo "<p style='color:red;'>".$error."</p>";
 }
 ?>

<label>UserName</label>
  <input type="text" name="username"><br>
  <label>Password</label>
  <input type="password" name="password"><br>
  <input type="submit" name="save" value="Create account">

 </form>

 <p>Have an account?<a href="index.php">Login here</a></p>
</div>
</body>
</html>