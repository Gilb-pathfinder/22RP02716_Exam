<?php
require_once 'db.php';
include 'auth.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Page</title>
</head>
<body>
    

<h2>Welcome to Your Dashboard <?php echo $_SESSION['UserName'];?>!</h2>
<button><a href="insert_emp.php">Add a New Employee</a></button>
<button><a href="view.php">Add a New Employee</a></button>
<button><a href="logout.php">SignOut</a></button>

</body>
</html>