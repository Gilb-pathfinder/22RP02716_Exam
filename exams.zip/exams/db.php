<?php

$connect = mysqli_connect("localhost","root","","nextech_portal_22rp02716");

if(!$connect){
  
    echo"Connection Failed:". mysqli_connect_error();
}

?>