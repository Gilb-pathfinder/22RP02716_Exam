<?php

require_once 'db.php';
include 'auth.php';

$id = $_GET['id'];

$sql = "DELETE FROM employees WHERE id = '$id'";
$result = mysqli_query($connect,$sql);

if($result){
 
    header("Location: view.php");
}
else{
    echo"Unable to Delete". mysqli_connect_error();
}

?>