
<?php
require_once 'db.php';
include 'auth.php';

$errors = [];

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $names = htmlspecialchars($_POST['names']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $position = htmlspecialchars($_POST['position']);
    $address = htmlspecialchars($_POST['address']);

    if(empty($names)){
     $errors[] = "Invalid Names";
    }
   else if(empty($email) ||!filter_var($email,FILTER_VALIDATE_EMAIL)){
        $errors[] = "Invalid Email format";
       }
       else if(empty($phone)){
        $errors[] = "Invalid Phone number";
       }
       else if(empty($position)){
        $errors[] = "Position Field is required";
       }
       else if(empty($address)){
        $errors[] = "Address field is required";
       }
 else{
    $insert = "INSERT INTO employees (employee_name,email,phone,position,address) VALUES ('$names','$email','$phone','$position','$address')";
    $exec = mysqli_query($connect,$insert);

   header("Location: view.php");
  }

       }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register new Employee</title>
</head>
<body>
  


<div class="container">
<button><a href="view.php">Employee list</a></button>
<button><a href="logout.php">Logout</a></button>
<h1>Register a new Employee</h1>
 <form action="" method="POST">

 <?php 
 foreach($errors as $error){
    echo "<p style='color:red;'>".$error."</p>";
 }
 ?>

<label>Emp_Names</label>
  <input type="text" name="names"><br>
  <label>Email</label>
  <input type="email" name="email"><br>
  <label>Phone Number</label>
  <input type="text" name="phone"><br>
  <label>Position</label>
  <input type="text" name="position"><br>
  <label>Address</label>
  <input type="text" name="address"><br>
  <input type="submit" name="save" value="Register">
 </form><br>

 <button><a href="view.php">View The Registered</a></button>
</div>
</body>
</html>