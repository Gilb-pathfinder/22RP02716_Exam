


<?php
require_once 'db.php';
include 'auth.php';

$errors = [];

$id = $_GET['id'];

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $names = htmlspecialchars($_POST['names']);
    $email = htmlspecialchars($_POST['email']);
    $phone = htmlspecialchars($_POST['phone']);
    $position = htmlspecialchars($_POST['position']);
    $address = htmlspecialchars($_POST['address']);

    if(empty($names)){
     $errors[] = "Invalid Names";
    }
   else if(empty($email) ||!filter_var($email,FILTER_VALIDATE_EMAIL)){
        $errors[] = "Invalid Email format";
       }
       else if(empty($phone)){
        $errors[] = "Invalid Phone number";
       }
       else if(empty($position)){
        $errors[] = "Position Field is required";
       }
       else if(empty($address)){
        $errors[] = "Address field is required";
       }
 else{
    $insert = "UPDATE employees SET employee_name = '$names', email = '$email', phone = '$phone', position = '$position', address = '$address' WHERE id = '$id'";
    $exec = mysqli_query($connect,$insert);

    if($exec == TRUE){
        header("Location: view.php");
    }
    else{

        echo "Error:" . $sql . "<br>" . $conn->error;
    }

  }
}
else {

    $query = "SELECT * FROM employees WHERE id = '$id'";
    $result = mysqli_query($connect,$query);
    $row = $result->fetch_assoc();

}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Employees info</title>
</head>
<body>
  

<div class="container">
<h1>Edit Employee's Information</h1>

<button><a href="view.php">Back to employee list</a></button>
<button><a href="logout.php">Logout</a></button>

 <form action="" method="POST">

 <?php 
 foreach($errors as $error){
    echo "<p style='color:red;'>".$error."</p>";
 }
 ?>

<label>Emp_Names</label>
  <input type="text" name="names" value="<?php echo $row['employee_name'];?>"><br>
  <label>Email</label>
  <input type="email" name="email" value="<?php echo $row['email'];?>"><br>
  <label>Phone Number</label>
  <input type="text" name="phone" value="<?php echo $row['phone'];?>"><br>
  <label>Position</label>
  <input type="text" name="position" value="<?php echo $row['position'];?>"><br>
  <label>Address</label>
  <input type="text" name="address" value="<?php echo $row['address'];?>"><br>
  <input type="submit" name="save" value="Register">
 </form><br>

 <button><a href="view.php">View The Registered</a></button>
</div>
</body>
</html>