<?php
session_start();

session_destroy();
setcookie('UserName','',time() - 360, "/");

header("Location: index.php");
exit;

?>