<?php

require_once 'db.php';

include 'auth.php';

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registered Employees</title>
</head>
<body>
    
<h2>The list of Registered Employees</h2>

<button><a href="insert_emp.php">Add a New Employee</a></button>
<button><a href="logout.php">Logout</a></button>
<table border="1" style="border-collapse: collapse;">
<tr>
    <th>Id</th>
    <th>Emp_Name</th>
    <th>Email</th>
    <th>Phone Number</th>
    <th>Position</th>
    <th>Address</th>
    <th>Action</th>
</tr>

<?php

$sql = "SELECT * FROM employees";
$result = mysqli_query($connect,$sql);
if($result && mysqli_num_rows($result)>0){

    while($row = $result->fetch_assoc()){
       ?>

<tr>
    <td><?php echo $row['id'];?></td>
    <td><?php echo $row['employee_name'];?></td>
    <td><?php echo $row['email'];?></td>
    <td><?php echo $row['phone'];?></td>
    <td><?php echo $row['position'];?></td>
    <td><?php echo $row['address'];?></td>

    <td>
        <a href="update.php?id=<?php echo $row['id'];?>">Update</a>
        <a href="delete.php?id=<?php echo $row['id'];?>">Delete</a>
    </td>
</tr>

<?php
    }

}
?>
</table>

</body>
</html>