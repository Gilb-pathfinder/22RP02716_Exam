
<?php
session_start();
require_once 'db.php';

$errors = [];

if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    $username = test_input($_POST['username']);
    $password = test_input($_POST['password']);

    if(empty($username)){
     $errors[] = "UserName is required! ";
    }
    if(empty($password)){
        $errors[] = "Password is required! ";
       }
if(empty($errors)){

  $sql =mysqli_query($connect,"SELECT * FROM users WHERE username = '$username'");
  $user = mysqli_fetch_assoc($sql);
  
  if($user && password_verify($password,$user['password'])){
   
    $_SESSION['UserName'] = $user['username'];

    if(!empty($_POST['remember'])){
    
  setcookie("UserName",serialize($_POST['username']),time() + (60*60*24*7),"/");
    }
    header("Location: welcome.php");
    exit;
  }

 }
}

function test_input($data){
    $data=htmlentities($data);
    $data=trim($data);
    $data=stripslashes($data);
    return $data;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create your account</title>
</head>
<body>
  

<div class="container">
<h1>Create account</h1>
 <form action="" method="POST">

 <?php 
 foreach($errors as $error){
    echo "<p style='color:red;'>".$error."</p>";
 }
 ?>

<label>UserName</label>
  <input type="text" name="username"><br>
  <label>Password</label>
  <input type="password" name="password"><br>
  <input type="checkbox" name="remember" value="yes"> Remember Me <br>
  <input type="submit" name="save" value="Login">

 </form>

 <p>Have no account?<a href="register.php">signup here</a></p>
</div>
</body>
</html>